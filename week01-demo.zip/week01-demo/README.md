# 953261 Week 1 — Demo files (lecturer / TA)

## Contents

| File | Use it for |
|---|---|
| `check-setup.js` | Students run `node check-setup.js` at the end of Part A. Every required line must show ✅ before TA check-off. Written in CommonJS so it still runs (and reports the problem) on an old Node version. |
| `01-http-server/` | Live lecture demo of the request–response cycle using only Node's built-in `http` module — no npm install needed. |

## Running the lecture demo

```bash
cd 01-http-server
npm start          # or: npm run dev  (auto-restarts on save)
```

Open <http://localhost:3000> with **DevTools → Network** visible, and keep the terminal on screen next to it.

### Suggested demo script (≈10 min)

1. **GET /** — point at the terminal: method, path, Host, User-Agent arrive at the server. In Network, click the request → *Headers*: status `200`, `Content-Type: text/html`. Reload: the time changes → it is generated per request.
2. **GET /api/course** — same cycle, but the body is JSON. "Same protocol, different content type." (Preview of Week 3 and Week 10.)
3. **GET form vs POST form** — the GET form puts `?q=...` in the URL; the POST form sends data in the body (Network → *Payload*). Server replies `201 Created`.
4. **Status codes** — click /old-page (301 then 200: two requests in Network), /secret (401), /does-not-exist (404), /crash (500). Ask: "whose fault is a 4xx vs a 5xx?"
5. **Same thing from the terminal** — show that a browser is just one kind of client:

```bash
curl -i http://localhost:3000/api/course
curl -i http://localhost:3000/old-page
curl -i -X POST -d "name=Toey&studentId=650000000" http://localhost:3000/echo
curl -v http://localhost:3000/ 2>&1 | head -20     # shows the raw request lines (>) and response lines (<)
```

6. Close with: "In Week 4 we rewrite this whole file in Express 5 — about a third of the code."

## Lab starter (`lab01-starter/`)

Students download this folder as `lab01-starter.zip` from Mango. It unzips to a `lab01/` folder inside their course folder `~/953261`, which is their single course repository `953261-labs` (one folder per lab). A model solution for TAs is in `lab01-solution/`.
